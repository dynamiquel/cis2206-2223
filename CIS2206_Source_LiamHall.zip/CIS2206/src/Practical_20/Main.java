package Practical_20;

public class Main {
    public static void main(String[] args) throws SierpinskiCarpet.InvalidBoardSizeException {
        var carpet = new SierpinskiCarpet(243);
        System.out.println(carpet);
    }
}