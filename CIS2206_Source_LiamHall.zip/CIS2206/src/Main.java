public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");

        double x = 10000000000L;
        System.out.println(x);
    }
}
